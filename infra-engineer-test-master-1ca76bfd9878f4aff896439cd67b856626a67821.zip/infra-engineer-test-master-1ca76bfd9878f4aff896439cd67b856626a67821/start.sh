#!/bin/sh 
set -e

docker-compose up --build